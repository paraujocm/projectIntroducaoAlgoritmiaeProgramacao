//
//  Created by Pedro Mota on 10/11/17.
//  Copyright � 2017 Pedro Mota. All rights reserved.
//

#include <stdio.h>
#include <string.h>

#define TAM_NOME 100	    // tamanho max de char na string
#define TAM_VECTOR 100	// numero de musicas que podem ser armazenadas em memoria

// estruturas permitem definir novos tipos de dados

typedef struct filme {
    char titulo[TAM_NOME];
    char ano [TAM_NOME];
    char ator [TAM_NOME];
    char genero[TAM_NOME];
    char duracao[TAM_NOME];
    char idade_min[TAM_NOME];
} FILME;

typedef struct ator {
    char nome[TAM_NOME];
    FILME vec_filme[TAM_VECTOR];
    int num_filmes;
} ATOR;

typedef struct cinema {
    char nome[TAM_NOME];
    char filme[TAM_NOME];
    FILME vec_filme[TAM_VECTOR];
    int num_filmes;
} CINEMA;

typedef struct genero {
    char nome[TAM_NOME];
    FILME vec_filme[TAM_VECTOR];
    int num_filmes;
} GENERO;

// variaveis globais

FILME vec_filme[TAM_VECTOR]; // inicializa-se o vetor com a estrutura criada em cima
int num_filmes=0;   // numero de filmes no vector
char ficheiro_filmes[] = "filmes.txt"; // nome do ficheiro
char ficheiro_filmes_bin[] = "filmesbin.txt"; // nome do ficheiro

ATOR vec_ator[TAM_VECTOR];
int num_atores=0;
char ficheiro_atores[] = "atores.txt";
char ficheiro_atores_bin[] = "atoresbin.txt";

CINEMA vec_cinema[TAM_VECTOR];
int num_cinemas=0;
char ficheiro_cinemas[] = "cinemas.txt";
char ficheiro_cinemas_bin[] = "cinemasbin.txt";

GENERO vec_genero[TAM_VECTOR];
int num_genero=0;
char ficheiro_genero[] = "genero.txt";
char ficheiro_genero_bin[] = "generobin.txt";

char ficheiro_editar[] = "editar.txt";

//Todas fun��es

void informacoes(void);

void ler_novo_filme(FILME * m);
void lista_todos_filmes(void);
void apagar_filme(FILME * m);
void editar_filme(FILME * m);
void lista_filmes_cinemas_por_genero(void);
void associa_filmes_cinemas(void);

void ler_novos_atores (ATOR * m);
void apagar_atores (ATOR * m);
void editar_atores (ATOR * m);
void lista_todos_atores (void);
void associa_atores_filmes(void);
void lista_filmes_ator(void);

void lista_todos_cinemas (void);
void ler_novos_cinemas (CINEMA * m);
void apagar_cinema(CINEMA * m);

void lista_todos_generos (void);
void ler_novos_generos (GENERO * m);
void apagar_genero(GENERO * m);

void gravar_para_ficheiro(void);
void carregar_do_ficheiro(void);
void gravar_para_ficheiro_bin(void);
void carregar_do_ficheiro_bin(void);

// FILMES

void imprime_filmes(FILME * m){
    printf("-Info sobre o filme\n");
    printf("\tTitulo do filme: %s\n", m->titulo);
    printf("\tAno: %s\n", m->ano);
    printf("\tAtor: %s\n", m->ator);
    printf("\tGenero: %s\n", m->genero);
    printf("\tDuracao(minutos): %s\n", m->duracao);
    printf("\tIdade Minima: %s\n", m->idade_min);
}

void lista_todos_filmes(){
    int i;
    printf("\n----Lista dos filmes----\n");
    for (i=0; i<num_filmes; i++)
        imprime_filmes(&vec_filme[i]);
    printf("\n-------------------------\n");
}

void ler_novo_filme(FILME * m){
    getchar();
    printf("Insira o titulo do filme:");
    gets(m->titulo);
    printf("Insira o ano:");
    gets(m->ano);
    printf("Insira o ator:");
    gets(m->ator);
    printf("Insira o genero:");
    gets(m->genero);
    printf("Insira a duracao(minutos):");
    gets(m->duracao);
    printf("Insira a idade minima:");
    gets(m->idade_min);
}

void apagar_filme(FILME * m){
    int i,j;
    int eliminado=0;
    char apagar_filme[TAM_NOME];
    lista_todos_filmes();
    printf("\n---Introduza o filme que pretende apagar---\n");
    scanf("%s", &apagar_filme);
    for (i=0; i<num_filmes; i++)
    {
        if(strcmp(vec_filme[i].titulo, apagar_filme)==0)
        {
            printf("titulo: %s\n", vec_filme[i].titulo);
            printf("ano: %s\n", vec_filme[i].ano);
            printf("ator: %s\n", vec_filme[i].ator);
            printf("genero: %s\n", vec_filme[i].genero);
            printf("dura�ao(minutos): %s\n", vec_filme[i].duracao);
            printf("idade minima: %s\n", vec_filme[i].idade_min);
            for(j=i; j<num_filmes; j++)
            {
                strcpy(vec_filme[j].titulo, vec_filme[j+1].titulo);
                strcpy(vec_filme[j].ano, vec_filme[j+1].ano);
                strcpy(vec_filme[j].ator, vec_filme[j+1].ator);
                strcpy(vec_filme[j].genero, vec_filme[j+1].genero);
                strcpy(vec_filme[j].duracao, vec_filme[j+1].duracao);
                strcpy(vec_filme[j].idade_min, vec_filme[j+1].idade_min);
            }
            eliminado=1;
        }
    }
    if (eliminado==1) {
        num_filmes--;
        printf("\nFilme eliminado com sucesso!\n");
    }
    else {
        printf("\nFilme nao encontrado!\n");
    }
}

void editar_filme(FILME * m){
    int i;
    int editado=0;
    FILE*fp;
    FILE*fp1;
    char editar_filme[TAM_NOME];
    lista_todos_filmes();
    printf("\n---Introduza o filme que pretende editar---\n");
    fp = fopen(ficheiro_filmes, "r");
    fp1= fopen(ficheiro_editar,"w");
    for (i=0; i<num_filmes; i++)
    {
        if(strcmp(vec_filme[i].titulo, editar_filme)==0)
        {
            printf("titulo: %s\n", vec_filme[i].titulo);
            printf("ano: %s\n", vec_filme[i].ano);
            printf("ator: %s\n", vec_filme[i].ator);
            printf("genero: %s\n", vec_filme[i].genero);
            printf("dura�ao(minutos): %s\n", vec_filme[i].duracao);
            printf("idade minima: %s\n", vec_filme[i].idade_min);
            fgets(editar_filme,sizeof(editar_filme),fp);
            fprintf(fp1,"%s",editar_filme);
            editado=1;
        }
    }
    if (editado==1) {
        num_filmes--;
        printf("\nFilme editado com sucesso!\n");
    }
    else {
        printf("\nFilme nao encontrado!\n");
    }
    fclose(fp);
    fclose(fp1);
    remove(ficheiro_filmes);
    rename(ficheiro_editar,ficheiro_filmes);
}

void lista_filmes_por_genero(){
    int i;
    int dd;
    char genero[TAM_NOME];
    lista_todos_generos();
    printf("\nDigite o genero de filmes:\n");
    scanf("%s",&genero);
    for (i=0; i<num_filmes; i++)
    {
        if(strcmp(vec_filme[i].genero, genero)==0)
        {
            printf("titulo: %s\n", vec_filme[i].titulo);
            printf("ano: %s\n", vec_filme[i].ano);
            printf("ator: %s\n", vec_filme[i].ator);
            printf("genero: %s\n", vec_filme[i].genero);
            printf("dura�ao(minutos): %s\n", vec_filme[i].duracao);
            printf("idade minima: %s\n", vec_filme[i].idade_min);
            dd=1;
        }
    }
    if (dd==1) {
        printf("\nSucesso!\n");
    }
    else {
        printf("\nEste genero nao tem nenhum filme associado!\n");
    }
}

void associa_filmes_cinemas(){
    int i;
    int dd;
    char filme[TAM_NOME];
    lista_todos_filmes();
    printf("\nDigite o filme que pretende associar ao cinema:\n");
    scanf("%s",&filme);
    for (i=0; i<num_cinemas; i++)
    {
        if(strcmp(vec_cinema[i].filme, filme)==0)
        {
            printf("Nome: %s\n", vec_cinema[i].nome);
            printf("Filme: %s\n", vec_cinema[i].filme);
            dd=1;
        }
    }
    if (dd==1) {
        printf("\nSucesso!\n");
    }
    else {
        printf("\nEste filme nao tem nenhum cinema associado!\n");
    }
}

//ATORES

void imprime_atores(ATOR * m){
    printf("-Info sobre o ator\n");
    printf("\tNome do atore: %s\n", m->nome);
}

void lista_todos_atores(){
    int i;
    printf("\n----Lista dos atores----\n");
    for (i=0; i<num_atores; i++)
        imprime_atores(&vec_ator[i]);
    printf("\n-------------------------\n");

}

void ler_novos_atores (ATOR * m){
    getchar();
    printf("Insira o nome do ator:");
    gets(m->nome);
}

void apagar_atores (ATOR * m){
    int i,j;
    int eliminado=0;
    char apagar_atores[TAM_NOME];
    lista_todos_atores();
    printf("\n---Introduza o ator que pretende apagar---\n");
    scanf("%s", &apagar_atores);
    for (i=0; i<num_atores; i++)
    {
        if(strcmp(vec_ator[i].nome, apagar_atores)==0)
        {
            printf("\nnome: %s\n", vec_ator[i].nome);
            for(j=i; j<num_atores; j++)
            {
                strcpy(vec_ator[j].nome, vec_ator[j+1].nome);
            }
            eliminado=1;
        }
    }
    if (eliminado==1) {
        num_atores--;
        printf("\nAtor eliminado com sucesso!\n");
    }
    else {
        printf("\nAtor nao encontrado!\n");
    }
}

void editar_atores (ATOR * m){
    int i;
    int editado=0;
    FILE*fa;
    FILE*fa1;
    char editar_atores[TAM_NOME];
    lista_todos_filmes();
    printf("\n---Introduza o ator que pretende editar---\n");
    fa = fopen(ficheiro_atores, "r");
    fa1= fopen(ficheiro_editar,"w");
    for (i=0; i<num_atores; i++)
    {
        if(strcmp(vec_ator[i].nome, editar_atores)==0)
        {
            printf("titulo: %s\n", vec_ator[i].nome);
            fgets(editar_atores,sizeof(editar_atores),fa);
            fprintf(fa1,"%s",editar_atores);
            editado=1;
        }
    }
    if (editado==1) {
        num_atores--;
        printf("\nAtor editado com sucesso!\n");
    }
    else {
        printf("\nAtor nao encontrado!\n");
    }
    fclose(fa);
    fclose(fa1);
    remove(ficheiro_atores);
    rename(ficheiro_editar,ficheiro_atores);
}

void associa_atores_filmes(){
    int i;
    int dd;
    char ator[TAM_NOME];
    lista_todos_atores();
    printf("\nDigite o ator que pretende associar ao filme:\n");
    scanf("%s",&ator);
    for (i=0; i<num_filmes; i++)
    {
        if(strcmp(vec_filme[i].ator, ator)==0)
        {
            printf("titulo: %s\n", vec_filme[i].titulo);
            printf("ano: %s\n", vec_filme[i].ano);
            printf("ator: %s\n", vec_filme[i].ator);
            printf("genero: %s\n", vec_filme[i].genero);
            printf("dura�ao(minutos): %s\n", vec_filme[i].duracao);
            printf("idade minima: %s\n", vec_filme[i].idade_min);
            dd=1;
        }
    }
    if (dd==1) {
        printf("\nSucesso!\n");
    }
    else {
        printf("\nEste ator nao tem nenhum filme associado!\n");
    }
}

void lista_filmes_ator(){
    int i;
    int dd;
    char ator[TAM_NOME];
    lista_todos_atores();
    printf("\nDigite o ator que pretende obter informacoes:\n");
    scanf("%s",&ator);
    for (i=0; i<num_filmes; i++)
    {
        if(strcmp(vec_filme[i].ator, ator)==0)
        {
            printf("titulo: %s\n", vec_filme[i].titulo);
            printf("ano: %s\n", vec_filme[i].ano);
            printf("ator: %s\n", vec_filme[i].ator);
            printf("genero: %s\n", vec_filme[i].genero);
            printf("dura�ao(minutos): %s\n", vec_filme[i].duracao);
            printf("idade minima: %s\n", vec_filme[i].idade_min);
            dd=1;
        }
    }
    if (dd==1) {
        printf("\nSucesso!\n");
    }
    else {
        printf("\nEste ator nao tem nenhum filme associado!\n");
    }
}

//CINEMAS

void imprime_cinemas(CINEMA * m){
    printf("-Info sobre o cinemas\n");
    printf("\tNome do cinema: %s\n", m->nome);
    printf("\tFilmes: %s\n", m->filme);
}

void ler_novos_cinemas (CINEMA * m){
    getchar();
    printf("Insira um novo cinema:");
    gets(m->nome);
    printf("Insira o filme:");
    gets(m->filme);
}

void lista_todos_cinemas(){
    int i;
    printf("\n----Lista dos cinemas----\n");
    for (i=0; i<num_cinemas; i++)
        imprime_cinemas(&vec_cinema[i]);
    printf("\n-------------------------\n");
}

void apagar_cinema(CINEMA * m){
    int i,j;
    int eliminado=0;
    char apagar_cinema[TAM_NOME];
    lista_todos_cinemas();
    printf("\n---Introduza o cinema que pretende apagar---\n");
    scanf("%s", &apagar_cinema);
    for (i=0; i<num_cinemas; i++)
    {
        if(strcmp(vec_cinema[i].nome, apagar_cinema)==0)
        {
            printf("nome: %s\n", vec_cinema[i].nome);
            printf("filme: %s\n", vec_cinema[i].filme);
            for(j=i; j<num_cinemas; j++)
            {
                strcpy(vec_cinema[j].nome, vec_cinema[j+1].nome);
                strcpy(vec_cinema[j].nome, vec_cinema[j+1].filme);
            }
            eliminado=1;
        }
    }
    if (eliminado==1) {
        num_cinemas--;
        printf("\nCinema eliminado com sucesso!\n");
    }
    else {
        printf("\nCinema nao encontrado!\n");
    }
}

//GENEROS

void imprime_generos(GENERO * m){
    printf("-Info sobre o genero\n");
    printf("\tGenero: %s\n", m->nome);
}

void ler_novos_generos(GENERO * m){
    getchar();
    printf("Insira o genero:");
    gets(m->nome);
}

void lista_todos_generos(){
    int i;
    printf("\n----Lista dos generos----\n");
    for (i=0; i<num_genero; i++)
        imprime_generos(&vec_genero[i]);
    printf("\n-------------------------\n");

}

void apagar_genero(GENERO * m){
    int i,j;
    int eliminado=0;
    char apagar_genero[TAM_NOME];
    lista_todos_generos();
    printf("\n---Introduza o genero que pretende apagar---\n");
    scanf("%s", &apagar_genero);
    for (i=0; i<num_genero; i++)
    {
        if(strcmp(vec_genero[i].nome, apagar_genero)==0)
        {
            printf("genero: %s\n", vec_genero[i].nome);
            for(j=i; j<num_genero; j++)
            {
                strcpy(vec_genero[j].nome, vec_genero[j+1].nome);
            }
            eliminado=1;
        }
    }
    if (eliminado==1) {
        num_genero--;
        printf("\nGenero eliminado com sucesso!\n");
    }
    else {
        printf("\nGenero nao encontrado!\n");
    }
}

void informacoes() {
    printf("\nTraballho realizado por:\n\nPedro Mota (33904)\nUniversidade Fernando Pessoa\n13/01/2018\n");
}

int main(int argc, const char * argv[]){
    menu();
    return 0;
}

void menu(){
    char op;
    do {
        printf("\n\nEscolha uma das seguintes opcoes:\n\n");
        printf(" [1]Carregar do ficheiro para a memoria\n");
        printf(" [2]Carregar do ficheiro binario para a memoria\n");
        printf(" [3]FILMES\n");
        printf(" [4]ATORES\n");
        printf(" [5]CINEMAS\n");
        printf(" [6]GENEROS\n");
        printf(" [7]Gravar para ficheiro\n");
        printf(" [8]Gravar para ficheiro binario\n");
        printf(" [9]Info\n");
        printf(" [S]Sair\n");
        fflush(stdin); //Limpar Tela
        scanf(" %c", &op);
        switch (op) {
            case '1':
                printf("\nmenu 1\n");
                carregar_do_ficheiro();
                break;
            case '2':
                printf("\nmenu 2\n");
                carregar_do_ficheiro_bin();
                break;
            case '3':
                menu_filmes();
                break;
            case '4':
                menu_atores();
                break;
            case '5':
                menu_cinemas();
                break;
            case '6':
                menu_generos();
                break;
            case '7':
                printf("\nmenu 7\n");
                gravar_para_ficheiro();
                break;
            case '8':
                printf("\nmenu 8\n");
                gravar_para_ficheiro_bin();
                break;
            case '9':
                printf("\nmenu 9\n");
                informacoes();
                break;
            case 'S':
                break;
            default:
                printf("\nOpcao invalida!!!\n");
        }
        if (op!='s' && op!='S') {
            printf("\n\nPrima qualquer tecla para voltar ao menu...\n\n");
            getchar();
        }
    }  while (op!='s' && op!='S');
}

void menu_filmes(){
    char op;
    printf("\nmenu 3 : FILMES \n");
                do {
                printf("\nEscolha uma das seguintes opcoes:\n\n");
                printf(" [1]Listar filmes\n");
                printf(" [2]Apagar filmes\n");
                printf(" [3]Editar filmes\n");
                printf(" [4]Inserir novo filme\n");
                printf(" [5]listar os filmes disponiveis por genero\n");
                printf(" [6]Associar filmes aos cinemas\n");
                printf(" [S]Voltar\n");
                fflush(stdin);
                scanf(" %c", &op);
                switch (op) {
                    case '1':
                        printf("\nmenu 1\n");
                        lista_todos_filmes();
                        break;
                    case '2':
                        printf("\nmenu 2\n");
                        apagar_filme(&vec_filme[num_filmes]);
                        break;
                    case '3':
                        printf("\nmenu 3\n");
                        editar_filme(&vec_filme[num_filmes]);
                        break;
                    case '4':
                        printf("\nmenu 4\n");
                        ler_novo_filme(&vec_filme[num_filmes]);
                        num_filmes++; // aumenta o numero de filmes no vector
                        break;
                    case '5':
                        printf("\nmenu 5\n");
                        lista_filmes_por_genero();
                        break;
                    case '6':
                        printf("\nmenu 6\n");
                        associa_filmes_cinemas();
                        break;
                        case 's':
                        menu();
                        break;
                }
                if (op!='s' && op!='S') {
            printf("\n\nPrima qualquer tecla para voltar ao menu...\n\n");
            getchar();
        }
                }while (op!='s' && op!='S');
}

void menu_atores(){
    char op;
    printf("\nmenu 4 : ATORES \n");
                do {
                printf("\nEscolha uma das seguintes opcoes:\n\n");
                printf(" [1]Listar atores\n");
                printf(" [2]Apagar atores\n");
                printf(" [3]Editar atores\n");
                printf(" [4]Inserir novo ator\n");
                printf(" [5]Associar atores aos filmes\n");
                printf(" [6]Listar os filmes de um determinado ator\n");
                printf(" [S]Voltar\n");
                fflush(stdin);
                scanf(" %c", &op);
                switch (op) {
                    case '1':
                        printf("\nmenu 1\n");
                        lista_todos_atores();
                        break;
                    case '2':
                        printf("\nmenu 2\n");
                        apagar_atores(&vec_ator[num_atores]);
                        break;
                    case '3':
                        printf("\nmenu 3\n");
                        editar_atores(&vec_ator[num_atores]);
                        break;
                    case '4':
                        printf("\nmenu 4\n");
                        ler_novos_atores(&vec_ator[num_atores]);
                        num_atores++; // aumenta o numero de atores no vector
                        break;
                    case '5':
                        printf("\nmenu 5\n");
                        associa_atores_filmes();
                        break;
                    case '6':
                        printf("\nmenu 6\n");
                        lista_filmes_ator();
                        break;
                    case 's':
                        menu();
                        break;
                }
                if (op!='s' && op!='S') {
            printf("\n\nPrima qualquer tecla para voltar ao menu...\n\n");
            getchar();
        }
                }while (op!='s' && op!='S');
}

void menu_cinemas(){
    char op;
    printf("\nmenu 5 : CINEMAS\n");
                do {
                printf("\nEscolha uma das seguintes opcoes:\n\n");
                printf(" [1]Listar cinemas\n");
                printf(" [2]Inserir novo cinema\n");
                printf(" [3]Apagar cinema\n");
                printf(" [S]Voltar\n");
                fflush(stdin);
                scanf(" %c", &op);
                switch (op) {
                    case '1':
                        printf("\nmenu 1\n");
                        lista_todos_cinemas();
                        break;
                    case '2':
                        printf("\nmenu 2\n");
                        ler_novos_cinemas(&vec_cinema[num_cinemas]);
                        num_cinemas++; // aumenta o numero de atores no vector
                        break;
                    case '3':
                        printf("\nmenu 3\n");
                        apagar_cinema(&vec_cinema[num_cinemas]);
                        break;
                    case 's':
                        menu();
                        break;
                }
                if (op!='s' && op!='S') {
            printf("\n\nPrima qualquer tecla para voltar ao menu...\n\n");
            getchar();
        }
                }while (op!='s' && op!='S');
}

void menu_generos(){
    char op;
    printf("\nmenu 6 : GENEROS\n");
                do {
                printf("\nEscolha uma das seguintes opcoes:\n\n");
                printf(" [1]Listar generos\n");
                printf(" [2]Inserir novo genero\n");
                printf(" [3]Apagar genero\n");
                printf(" [S]Voltar\n");
                fflush(stdin);
                scanf(" %c", &op);
                switch (op) {
                    case '1':
                        printf("\nmenu 1\n");
                        lista_todos_generos();
                        break;
                    case '2':
                        printf("\nmenu 2\n");
                        ler_novos_generos(&vec_genero[num_genero]);
                        num_genero++; // aumenta o numero de atores no vector
                        break;
                    case '3':
                        printf("\nmenu 3\n");
                        apagar_genero(&vec_genero[num_genero]);
                        break;
                    case 's':
                        menu();
                        break;
                }
                if (op!='s' && op!='S') {
            printf("\n\nPrima qualquer tecla para voltar ao menu...\n\n");
            getchar();
        }
                }while (op!='s' && op!='S');
}

void gravar_para_ficheiro(){
    FILE * fp;
    FILE * fa;
    FILE * fc;
    FILE * fg;
    int i;
    fp = fopen(ficheiro_filmes, "w");
    fa = fopen(ficheiro_atores, "w");
    fc = fopen(ficheiro_cinemas, "w");
    fg = fopen(ficheiro_genero, "w");
    if (fp != NULL) {
        fprintf(fp,"filmes: %d\n",num_filmes);
        for (i=0; i<num_filmes; i++) {
            fprintf(fp,"\ntitulo: %s\n", vec_filme[i].titulo);
            fprintf(fp,"ano: %s\n", vec_filme[i].ano);
            fprintf(fp,"ator: %s\n", vec_filme[i].ator);
            fprintf(fp,"genero: %s\n", vec_filme[i].genero);
            fprintf(fp,"dura�ao(minutos): %s\n", vec_filme[i].duracao);
            fprintf(fp,"idade minima: %s\n", vec_filme[i].idade_min);
        }
    if (fa != NULL) {
        fprintf(fa,"atores: %d\n",num_atores);
        for (i=0; i<num_atores; i++) {
            fprintf(fa,"\nnome: %s\n", vec_ator[i].nome);
        }
    if (fc != NULL) {
        fprintf(fc,"cinemas: %d\n",num_cinemas);
        for (i=0; i<num_cinemas; i++) {
            fprintf(fc,"\nnome: %s\n", vec_cinema[i].nome);
            fprintf(fc,"filme: %s\n", vec_cinema[i].filme);
        }
    if (fg != NULL) {
        fprintf(fg,"generos: %d\n",num_genero);
        for (i=0; i<num_genero; i++) {
            fprintf(fg,"\ngenero: %s\n", vec_genero[i].nome);
        }
        printf("\nDados Gravados!\n");
        fclose(fp);
        fclose(fa);
        fclose(fc);
        fclose(fg);
    }
}
    }
}
}

void carregar_do_ficheiro(){
    FILE * fp;
    FILE * fa;
    FILE * fc;
    FILE * fg;
    int i=0;
    char linha[TAM_NOME];
    num_filmes = 0;
    num_atores = 0;
    num_cinemas = 0;
    num_genero = 0;
    fp = fopen(ficheiro_filmes, "r");
    fa = fopen(ficheiro_atores, "r");
    fc = fopen(ficheiro_cinemas, "r");
    fg = fopen(ficheiro_genero, "r");
    if (fp != NULL) {
        fscanf(fp,"%*s %d\n", &num_filmes);
        for (i=0; i<num_filmes; i++) {
            fgets(linha,sizeof(linha),fp); 			 // titulo
            linha[strlen(linha)-1]=0;                // retira quebra de linha
            strcpy(vec_filme[i].titulo, &linha[8]); // nome come�a no 8� char
            fgets(linha,sizeof(linha),fp); 			 // ano
            linha[strlen(linha)-1]=0;
            strcpy(vec_filme[i].ator, &linha[9]);
            fgets(linha,sizeof(linha),fp); 			 // ator
            linha[strlen(linha)-1]=0;
            strcpy(vec_filme[i].ano, &linha[10]);
            fgets(linha,sizeof(linha),fp); 			 // genero
            linha[strlen(linha)-1]=0;
            strcpy(vec_filme[i].genero, &linha[11]);
            fgets(linha,sizeof(linha),fp); 			// duracao
            linha[strlen(linha)-1]=0;
            strcpy(vec_filme[i].duracao, &linha[12]);
            fgets(linha,sizeof(linha),fp); 			// idade minima
            linha[strlen(linha)-1]=0;
            strcpy(vec_filme[i].idade_min, &linha[13]);
        }
    if (fa != NULL) {
        fscanf(fa,"%*s %d\n", &num_atores);
        for (i=0; i<num_atores; i++) {
            fgets(linha,sizeof(linha),fa); 			// nome
            linha[strlen(linha)-1]=0;
            strcpy(vec_ator[i].nome, &linha[8]);
        }
    if (fc != NULL) {
        fscanf(fc,"%*s %d\n", &num_cinemas);
        for (i=0; i<num_cinemas; i++) {
            fgets(linha,sizeof(linha),fc); 			// nome
            linha[strlen(linha)-1]=0;
            strcpy(vec_cinema[i].nome, &linha[8]);
            fgets(linha,sizeof(linha),fc); 			// filme
            linha[strlen(linha)-1]=0;
            strcpy(vec_cinema[i].filme, &linha[9]);
        }
    if (fg != NULL) {
        fscanf(fg,"%*s %d\n", &num_genero);
        for (i=0; i<num_genero; i++) {
            fgets(linha,sizeof(linha),fg); 			// nome
            linha[strlen(linha)-1]=0;
            strcpy(vec_genero[i].nome, &linha[8]);
        }
        printf("\nDados Carregados!\n");
        fclose(fp);
        fclose(fa);
        fclose(fc);
        fclose(fg);
    }
}
    }
}
}

void gravar_para_ficheiro_bin(){
    FILE *fp;
    FILE *fa;
    FILE *fc;
    FILE *fg;
    int i;
    fp = fopen(ficheiro_filmes_bin, "wb");
    fa = fopen(ficheiro_atores_bin, "wb");
    fc = fopen(ficheiro_cinemas_bin, "wb");
    fg = fopen(ficheiro_genero_bin, "wb");
    if (fp!=NULL)
    {
            fwrite(vec_filme,sizeof(FILME),num_filmes,fp);
    if (fa != NULL)
    {
            fwrite(vec_ator[i].nome,sizeof(ATOR),num_atores,fa);
    if (fc != NULL)
    {
            fwrite(vec_cinema[i].nome,sizeof(CINEMA),num_cinemas,fc);
    if (fg != NULL)
    {

            fwrite(vec_genero[i].nome,sizeof(GENERO),num_genero,fg);

        printf("\nDados binarios Gravados!\n");
        fclose(fp);
        fclose(fa);
        fclose(fc);
        fclose(fg);
    }
}
    }
}
}

void carregar_do_ficheiro_bin(){
    FILE *fp;
    FILE *fa;
    FILE *fc;
    FILE *fg;
    int i;
    long tamanho_ficheiro;
    fp = fopen(ficheiro_filmes_bin, "rb");
    fa = fopen(ficheiro_atores_bin, "rb");
    fc = fopen(ficheiro_cinemas_bin, "rb");
    fg = fopen(ficheiro_genero_bin, "rb");
    if (fp!=NULL)
    {
        fseek(fp,0,SEEK_END);
        tamanho_ficheiro = ftell(fp);
        num_filmes=(int)(tamanho_ficheiro/sizeof(FILME));
        fseek(fp,0,SEEK_SET);
        fread(vec_filme,sizeof(FILME),num_filmes,fp);
    if (fa!=NULL)
    {
        fseek(fa,0,SEEK_END);
        tamanho_ficheiro = ftell(fa);
        num_atores=(int)(tamanho_ficheiro/sizeof(FILME));
        fseek(fp,0,SEEK_SET);
        fread(vec_ator,sizeof(FILME),num_atores,fa);
    if (fc!=NULL)
    {
        fseek(fc,0,SEEK_END);
        tamanho_ficheiro = ftell(fc);
        num_cinemas=(int)(tamanho_ficheiro/sizeof(FILME));
        fseek(fp,0,SEEK_SET);
        fread(vec_cinema,sizeof(FILME),num_cinemas,fc);
    if (fg!=NULL)
    {
        fseek(fg,0,SEEK_END);
        tamanho_ficheiro = ftell(fg);
        num_genero=(int)(tamanho_ficheiro/sizeof(FILME));
        fseek(fp,0,SEEK_SET);
        fread(vec_genero,sizeof(FILME),num_genero,fg);

    printf("\nDados binarios Carregados!\n");
    fclose(fp);
    fclose(fa);
    fclose(fc);
    fclose(fg);
    }
    }
    }
    }
}
